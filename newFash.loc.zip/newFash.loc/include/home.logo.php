<h1>FASHION AND CREATIVITY</h1>	 
		<p>Sed dapibus est a lorem dictum, id dignissim lacus fermentum. Nulla ut nibh in libero maximus pretium
		Nunc vulputate vel tellus ac elementum. Duis nec tincidunt dolor, ac dictum eros.</p>
<?
$sSectionName = "Блог";
$arDirProperties = Array(

);
?>
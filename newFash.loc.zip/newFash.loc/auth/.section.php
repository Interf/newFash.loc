<?
$sSectionName = "Авторизация";
$arDirProperties = array(

);
?>
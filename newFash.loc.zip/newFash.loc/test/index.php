<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Тестовый раздел");
?>

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
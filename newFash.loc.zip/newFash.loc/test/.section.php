<?
$sSectionName = "Тестовый раздел";
$arDirProperties = Array(

);
?>
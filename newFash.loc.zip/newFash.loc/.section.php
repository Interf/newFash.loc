<?
$sSectionName = 'Главная';
$arDirProperties = array(
	'title' => 'Title',
	'description' => 'Description',
	'keywords' => 'Keywords',
	'robots' => 'index, follow'
);
?>
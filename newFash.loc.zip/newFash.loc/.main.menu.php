<?
$aMenuLinks = Array(
	Array(
		"Блог", 
		"/blog/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Test", 
		"/test/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>
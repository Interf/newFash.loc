<?
$sSectionName = "Оформление заказа";
$arDirProperties = Array(

);
?>
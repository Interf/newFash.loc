<?
$sSectionName = "Корзина";
$arDirProperties = Array(
	'title' => ""
);
?>
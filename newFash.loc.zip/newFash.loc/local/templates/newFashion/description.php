<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arTemplate = [
	"NAME" => "New Fashion",
	"DESCRIPTION" => "Шаблон сайта New Fashion"
];

?>
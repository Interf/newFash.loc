<?php
$MESS['MAIN_AUTH_FORM_SUCCESS'] = 'Вы зарегистрированы и успешно авторизовались.';
$MESS['MAIN_AUTH_FORM_HEADER'] = 'Пожалуйста, авторизуйтесь';
$MESS['MAIN_AUTH_FORM_FIELD_LOGIN'] = 'Логин';
$MESS['MAIN_AUTH_FORM_FIELD_PASS'] = 'Пароль';
$MESS['MAIN_AUTH_FORM_FIELD_CAPTCHA'] = 'Введите слово на картинке';
$MESS['MAIN_AUTH_FORM_FIELD_REMEMBER'] = 'Запомнить меня на этом компьютере';
$MESS['MAIN_AUTH_FORM_FIELD_SUBMIT'] = 'Войти';
$MESS['MAIN_AUTH_FORM_URL_FORGOT_PASSWORD'] = 'Забыли свой пароль?';
$MESS['MAIN_AUTH_FORM_URL_REGISTER_URL'] = 'Зарегистрироваться';
$MESS['MAIN_AUTH_FORM_SECURE_NOTE'] = 'Перед отправкой формы авторизации пароль будет зашифрован в браузере. Это позволит избежать передачи пароля в открытом виде.';
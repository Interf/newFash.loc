<?
$MESS["MAIN_AUTH_OTP_FIELD_CAPTCHA"] = "Type the characters you see on the picture";
$MESS["MAIN_AUTH_OTP_FIELD_OTP"] = "One-time password";
$MESS["MAIN_AUTH_OTP_FIELD_REMEMBER"] = "Remember code on this computer";
$MESS["MAIN_AUTH_OTP_FIELD_SUBMIT"] = "Log in";
$MESS["MAIN_AUTH_OTP_HEADER"] = "Please enter your one-time password";
$MESS["MAIN_AUTH_OTP_URL_AUTH_URL"] = "Authentication";
$MESS["MAIN_AUTH_OTP_URL_REGISTER_URL"] = "Register";
?>
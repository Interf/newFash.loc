<?
$MESS["MAIN_AUTH_FORM_FIELD_CAPTCHA"] = "Type the characters you see on the picture";
$MESS["MAIN_AUTH_FORM_FIELD_LOGIN"] = "Login";
$MESS["MAIN_AUTH_FORM_FIELD_PASS"] = "Password";
$MESS["MAIN_AUTH_FORM_FIELD_REMEMBER"] = "Remember me on this computer";
$MESS["MAIN_AUTH_FORM_FIELD_SUBMIT"] = "Log in";
$MESS["MAIN_AUTH_FORM_HEADER"] = "Please log in.";
$MESS["MAIN_AUTH_FORM_SECURE_NOTE"] = "The password will be encrypted before it is sent. This will prevent the password from appearing in open form over data transmission channels.";
$MESS["MAIN_AUTH_FORM_SUCCESS"] = "You are registered and logged in successfully.";
$MESS["MAIN_AUTH_FORM_URL_FORGOT_PASSWORD"] = "Forgot password?";
$MESS["MAIN_AUTH_FORM_URL_REGISTER_URL"] = "Register";
?>
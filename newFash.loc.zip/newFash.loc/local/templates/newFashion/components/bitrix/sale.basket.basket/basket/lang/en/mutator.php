<?
$MESS["SBB_DETAIL_PICTURE_NAME"] = "Detailed image";
$MESS["SBB_PREVIEW_TEXT_NAME"] = "Short description";
$MESS["SBB_PRICE_TYPE_NAME"] = "Price type";
$MESS["SBB_DISCOUNT_NAME"] = "Discount";
$MESS["SBB_WEIGHT_NAME"] = "Weight";
?>
<?

$MESS ['TSB1_PERSONAL'] = "Персональный раздел";

$MESS ['TSB1_EXPAND'] = "Раскрыть";
$MESS ['TSB1_COLLAPSE'] = "Скрыть";

$MESS ['TSB1_CART'] = "Корзина";
$MESS ['TSB1_TOTAL_PRICE'] = "На сумму";

$MESS ['TSB1_YOUR_CART'] = "Ваша корзина";

$MESS ['TSB1_READY'] = "Готовые к покупке товары";
$MESS ['TSB1_DELAY'] = "Отложенные товары";
$MESS ['TSB1_NOTAVAIL'] = "Недоступные товары";
$MESS ['TSB1_SUBSCRIBE'] = "Подписанные товары";

$MESS ['TSB1_SUM'] = "на сумму";
$MESS ['TSB1_DELETE'] = "Удалить";

$MESS ['TSB1_2ORDER'] = "Оформить заказ";
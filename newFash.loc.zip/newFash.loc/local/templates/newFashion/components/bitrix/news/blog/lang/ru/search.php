<?
$MESS ['T_NEWS_DETAIL_BACK'] = "Возврат к списку";
?>
<?
$sSectionName = "Каталог";
$arDirProperties = Array(
	'title' => ""
);
?>